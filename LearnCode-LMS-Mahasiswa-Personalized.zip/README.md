# LearnCode — LMS Pembelajaran Pemrograman Web

Versi upgraded untuk tugas mahasiswa. Bukan sekadar landing page: memiliki dashboard, kurikulum 6 modul, search, filter level, modal materi, progress tracking, assessment 10 soal, nilai, notes, dark mode, dan localStorage.

## Teknologi
- HTML5 semantic
- CSS3 responsive
- JavaScript ES6
- DOM manipulation
- localStorage
- CSS Grid/Flexbox
- Responsive UI

## Deploy tercepat
1. Extract ZIP.
2. Pastikan `index.html`, `style.css`, dan `script.js` berada dalam satu folder.
3. Buka https://app.netlify.com/drop
4. Login.
5. Drag folder project ke Drop.
6. Salin URL `.netlify.app`.

## Catatan presentasi
Jelaskan bahwa aplikasi ini adalah frontend learning management system sederhana. State seperti progress, nilai, dan catatan disimpan dengan localStorage sehingga tidak membutuhkan backend/database untuk demonstrasi tugas.


### Personalisasi pengguna
Saat pertama kali membuka website pada sebuah perangkat/browser, pengguna diminta memasukkan nama. Nama disimpan di `localStorage` perangkat tersebut, sehingga perangkat lain tidak akan otomatis menampilkan nama pemilik website. Nama dapat diganti dengan mengklik kartu profil di sidebar.
