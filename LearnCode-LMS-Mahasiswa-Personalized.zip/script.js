const modules=[
{id:"html",num:"01",level:"beginner",title:"HTML & Struktur Dokumen",desc:"Semantic HTML, struktur dokumen, heading, link, image, list, table, form dan accessibility.",tags:["HTML5","Semantic"],time:"25 menit",icon:"HTML",content:`<h2>HTML & Struktur Dokumen</h2><p>HTML adalah fondasi struktur halaman web. Gunakan elemen semantic agar struktur mudah dipahami browser, developer, dan teknologi bantu.</p><h4>Konsep inti</h4><p>Dokumen HTML memiliki <b>doctype</b>, <b>html</b>, <b>head</b>, dan <b>body</b>. Di dalam body, gunakan elemen sesuai maknanya: header, nav, main, section, article, footer.</p><h4>Contoh</h4><pre>&lt;main&gt;
  &lt;section&gt;
    &lt;h1&gt;Profil Mahasiswa&lt;/h1&gt;
    &lt;p&gt;Belajar web development.&lt;/p&gt;
  &lt;/section&gt;
&lt;/main&gt;</pre>`},
{id:"css",num:"02",level:"beginner",title:"CSS Fundamentals",desc:"Selector, box model, typography, warna, spacing dan teknik styling dasar.",tags:["CSS3","Styling"],time:"25 menit",icon:"CSS",content:`<h2>CSS Fundamentals</h2><p>CSS mengatur presentasi visual HTML. Pemahaman box model dan cascade adalah fondasi sebelum masuk ke layout kompleks.</p><h4>Box Model</h4><p>Setiap elemen memiliki content, padding, border, dan margin. Gunakan <b>box-sizing: border-box</b> agar perhitungan ukuran lebih mudah.</p><h4>Contoh</h4><pre>.card {
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 12px;
  box-sizing: border-box;
}</pre>`},
{id:"layout",num:"03",level:"intermediate",title:"Responsive Layout",desc:"Flexbox, CSS Grid, breakpoint, responsive unit dan desain mobile-first.",tags:["Flexbox","Grid"],time:"30 menit",icon:"RWD",content:`<h2>Responsive Layout</h2><p>Responsive design membuat interface beradaptasi dengan ukuran layar. Hindari layout yang hanya bagus di satu resolusi.</p><h4>Flexbox & Grid</h4><p>Gunakan Flexbox untuk susunan satu dimensi dan Grid untuk layout dua dimensi. Media query dipakai untuk mengubah layout pada breakpoint tertentu.</p><h4>Contoh</h4><pre>.grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
}
@media (max-width: 700px) {
  .grid { grid-template-columns: 1fr; }
}</pre>`},
{id:"js",num:"04",level:"beginner",title:"JavaScript Dasar",desc:"Variabel, tipe data, operator, kondisi, function dan event dasar.",tags:["ES6","Logic"],time:"30 menit",icon:"JS",content:`<h2>JavaScript Dasar</h2><p>JavaScript menambahkan logika dan perilaku dinamis pada halaman. Mulai dari variabel, kondisi, fungsi, array, dan event.</p><h4>Contoh</h4><pre>const tombol = document.querySelector("#btn");
tombol.addEventListener("click", () => {
  console.log("Tombol diklik");
});</pre>`},
{id:"dom",num:"05",level:"intermediate",title:"DOM & Interaktivitas",desc:"Manipulasi DOM, event listener, validasi form dan perubahan state halaman.",tags:["DOM","Events"],time:"35 menit",icon:"DOM",content:`<h2>DOM & Interaktivitas</h2><p>DOM adalah representasi struktur HTML yang dapat dimanipulasi JavaScript. Inilah yang membuat website merespons tindakan pengguna.</p><h4>Contoh</h4><pre>const title = document.querySelector("h1");
title.textContent = "Judul baru";
title.classList.add("active");</pre>`},
{id:"storage",num:"06",level:"intermediate",title:"Local Storage & State",desc:"Menyimpan data sederhana di browser dan membangun state aplikasi frontend.",tags:["Storage","State"],time:"30 menit",icon:"DB",content:`<h2>Local Storage & State</h2><p>localStorage memungkinkan data sederhana bertahan setelah browser ditutup. Cocok untuk preference, progress, atau catatan pada aplikasi tanpa backend.</p><h4>Contoh</h4><pre>localStorage.setItem("progress", "80");
const value = localStorage.getItem("progress");</pre>`}
];
const questions=[
["Elemen semantic yang paling tepat untuk konten utama halaman adalah?",["<main>","<div>","<span>","<b>"],0],
["CSS property untuk mengubah warna teks adalah...",["background","color","font","text"],1],
["Layout dua dimensi paling tepat menggunakan...",["Float","Flexbox","CSS Grid","Inline-block"],2],
["Keyword untuk membuat variabel yang tidak dapat di-reassign adalah...",["var","let","const","static"],2],
["API browser untuk mencari elemen berdasarkan selector CSS adalah...",["querySelector","findElement","getNode","select"],0],
["localStorage digunakan untuk...",["Menjalankan server","Menyimpan data sederhana di browser","Membuat database SQL","Mengirim email"],1],
["Media query digunakan untuk...",["Mengambil data API","Mengatur responsive breakpoint","Membuat variabel","Mengubah HTML"],1],
["Event listener berfungsi untuk...",["Mendengar aksi/event pengguna","Membuat database","Menghapus CSS","Membuat server"],0],
["Tag untuk membuat hyperlink adalah...",["<link>","<a>","<url>","<href>"],1],
["Konsep mobile-first berarti...",["Desktop selalu diprioritaskan","Desain dimulai dari perangkat mobile lalu diperluas","Tidak perlu responsive","Hanya membuat aplikasi mobile"],1]
];
let state=JSON.parse(localStorage.getItem("learncode_state")||'{"completed":[],"score":null,"minutes":0,"notes":[],"quizPassed":false}');
let active=null,quizIndex=0,quizScore=0,quizSelected=null;


const defaultUserName="Pengunjung";
function getUserName(){return localStorage.getItem("learncode_name")||""}
function initials(name){
  const parts=name.trim().split(/\s+/).filter(Boolean);
  if(!parts.length)return "?";
  return parts.slice(0,2).map(x=>x[0]).join("").toUpperCase();
}
function updateUserNameUI(){
  const name=getUserName();
  const display=name||defaultUserName;
  const profile=document.getElementById("profileName");
  const avatar=document.getElementById("profileAvatar");
  const topAvatar=document.getElementById("topAvatar");
  const welcome=document.getElementById("welcomeTitle");
  if(profile)profile.textContent=display;
  if(avatar)avatar.textContent=name?initials(name):"?";
  if(topAvatar)topAvatar.textContent=name?initials(name):"?";
  if(welcome)welcome.textContent=name?`Selamat datang kembali, ${name} 👋`:"Selamat datang di LearnCode 👋";
}
function openNameModal(){
  const input=document.getElementById("nameInput");
  if(input)input.value=getUserName();
  document.getElementById("nameModal").classList.remove("hidden");
  setTimeout(()=>input?.focus(),50);
}
function saveUserName(){
  const input=document.getElementById("nameInput");
  const name=input.value.trim().replace(/\s+/g," ");
  if(name.length<2){showToast("Masukkan nama minimal 2 karakter.");input.focus();return}
  localStorage.setItem("learncode_name",name);
  updateUserNameUI();
  document.getElementById("nameModal").classList.add("hidden");
  showToast(`Selamat datang, ${name}!`);
}

function save(){localStorage.setItem("learncode_state",JSON.stringify(state));updateUI()}
function updateUI(){
 const n=state.completed.length,p=Math.round(n/modules.length*100);
 document.getElementById("sidePct").textContent=p+"%";document.getElementById("sideBar").style.width=p+"%";
 document.getElementById("statLessons").textContent=n+" / "+modules.length;
 document.getElementById("statScore").textContent=state.score===null?"—":state.score+"/10";
 document.getElementById("statTime").textContent=state.minutes+" menit";
 document.getElementById("htmlDash").style.width=(state.completed.includes("html")?100:0)+"%";
 document.getElementById("htmlDashText").textContent=(state.completed.includes("html")?100:0)+"% selesai";
 setDonut("donut",p);setDonut("bigDonut",p);document.getElementById("donutPct").textContent=p+"%";document.getElementById("bigPct").textContent=p+"%";
 document.getElementById("materialPct").textContent=p+"%";document.getElementById("materialBar").style.width=p+"%";
 const qp=state.score===null?0:Math.min(100,state.score*10);document.getElementById("quizPct").textContent=qp+"%";document.getElementById("quizBar").style.width=qp+"%";
 document.getElementById("progressTitle").textContent=p===100?"Kurikulum selesai 🎉":p===0?"Belum mulai":p+"% kurikulum selesai";
 renderCompetency();renderNotes();
}
function setDonut(id,p){const el=document.getElementById(id);if(el)el.style.background=`conic-gradient(var(--primary) ${p*3.6}deg,#eeeef4 ${p*3.6}deg)`}
function renderCourses(list=modules){
 const grid=document.getElementById("courseGrid");
 grid.innerHTML=list.length?list.map(m=>`<article class="course-card"><div class="course-head"><div class="course-symbol ${m.id==="html"?"html":m.id==="css"?"css":""}">${m.icon}</div><span class="course-number">MODUL ${m.num}</span></div><h3>${m.title}</h3><p>${m.desc}</p><div class="course-tags">${m.tags.map(t=>`<span>${t}</span>`).join("")}</div><div class="course-footer"><small>${m.level==="beginner"?"Dasar":"Menengah"} · ${m.time}</small><button onclick="openLesson('${m.id}')">${state.completed.includes(m.id)?"✓ Selesai":"Pelajari →"}</button></div></article>`).join(""):`<div class="panel"><p class="muted">Materi tidak ditemukan.</p></div>`;
}
function searchCourses(q){q=q.toLowerCase();renderCourses(modules.filter(m=>(m.title+" "+m.desc+" "+m.tags.join(" ")).toLowerCase().includes(q)))}
function filterLevel(level,btn){document.querySelectorAll(".filter-btn").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderCourses(level==="all"?modules:modules.filter(m=>m.level===level))}
function openLesson(id){active=id;const m=modules.find(x=>x.id===id);document.getElementById("lessonModalContent").innerHTML=m.content;document.getElementById("completeBtn").textContent=state.completed.includes(id)?"✓ Modul Sudah Selesai":"✓ Tandai Modul Selesai";document.getElementById("lessonModal").classList.remove("hidden")}
function closeLesson(){document.getElementById("lessonModal").classList.add("hidden")}
function completeActive(){if(!state.completed.includes(active)){state.completed.push(active);state.minutes+=parseInt(modules.find(m=>m.id===active).time);save();showToast("Modul berhasil diselesaikan.");}closeLesson()}
function goTo(id){document.getElementById(id).scrollIntoView({behavior:"smooth"});document.querySelectorAll(".nav-link").forEach(a=>a.classList.toggle("active",a.dataset.section===id))}
function toggleSidebar(){document.getElementById("sidebar").classList.toggle("open")}
function toggleTheme(){document.body.classList.toggle("dark");localStorage.setItem("learncode_dark",document.body.classList.contains("dark"))}
function showToast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function resetData(){if(confirm("Reset semua progress dan catatan?")){localStorage.removeItem("learncode_state");location.reload()}}
function renderCompetency(){document.getElementById("competency").innerHTML=modules.map(m=>`<div class="competency-item"><span>${state.completed.includes(m.id)?"✓":"○"}</span><div><b>${m.title}</b><div class="muted">${state.completed.includes(m.id)?"Kompetensi selesai":"Belum diselesaikan"}</div></div></div>`).join("")}
function addNote(){const title=document.getElementById("noteTitle").value.trim(),body=document.getElementById("noteBody").value.trim();if(!title||!body){showToast("Isi judul dan isi catatan terlebih dahulu.");return}state.notes.unshift({title,body,date:new Date().toLocaleDateString("id-ID")});document.getElementById("noteTitle").value="";document.getElementById("noteBody").value="";save();showToast("Catatan disimpan.")}
function renderNotes(){const el=document.getElementById("notesList");el.innerHTML=state.notes.length?state.notes.map((n,i)=>`<div class="note-card"><h3>${n.title}</h3><p>${n.body}</p><small>${n.date} · Catatan ${i+1}</small></div>`).join(""):`<div class="panel"><p class="muted">Belum ada catatan. Buat rangkuman pertamamu.</p></div>`}
function startQuiz(){quizIndex=0;quizScore=0;quizSelected=null;document.getElementById("quizPanel").classList.remove("hidden");document.getElementById("quizResult").classList.add("hidden");renderQ();document.getElementById("quizPanel").scrollIntoView({behavior:"smooth",block:"center"})}
function renderQ(){const q=questions[quizIndex];document.getElementById("qNum").textContent=`Soal ${quizIndex+1}/10`;document.getElementById("qScore").textContent=quizScore+" benar";document.getElementById("qBar").style.width=((quizIndex+1)*10)+"%";document.getElementById("qText").textContent=q[0];document.getElementById("qAnswers").innerHTML=q[1].map((a,i)=>`<button class="answer" onclick="chooseQ(${i})">${a}</button>`).join("");document.getElementById("qNext").disabled=true;document.getElementById("qNext").textContent=quizIndex===9?"Selesaikan Evaluasi →":"Jawab & Lanjut →";quizSelected=null}
function chooseQ(i){if(quizSelected!==null)return;quizSelected=i;const q=questions[quizIndex],bs=document.querySelectorAll(".answer");bs[i].classList.add("selected");if(i===q[2]){quizScore++;bs[i].classList.add("correct")}else{bs[i].classList.add("wrong");bs[q[2]].classList.add("correct")}document.getElementById("qNext").disabled=false;document.getElementById("qScore").textContent=quizScore+" benar"}
function nextQ(){if(quizSelected===null)return;if(quizIndex<9){quizIndex++;renderQ()}else finishQuiz()}
function finishQuiz(){state.score=quizScore;state.quizPassed=quizScore>=8;save();document.getElementById("quizPanel").classList.add("hidden");const r=document.getElementById("quizResult");r.classList.remove("hidden");r.innerHTML=`<div class="eyebrow">HASIL EVALUASI</div><h2>${quizScore}/10</h2><p class="muted">${state.quizPassed?"LULUS — Pemahaman dasar kamu sudah memenuhi target.":"BELUM LULUS — Target minimal adalah 8/10. Pelajari kembali modul lalu ulangi evaluasi."}</p><button class="btn primary" onclick="startQuiz()">Ulangi Evaluasi</button>`}
document.querySelectorAll(".nav-link").forEach(a=>a.addEventListener("click",()=>goTo(a.dataset.section)));
if(localStorage.getItem("learncode_dark")==="true")document.body.classList.add("dark");
renderCourses();updateUI();updateUserNameUI();if(!getUserName())openNameModal();
